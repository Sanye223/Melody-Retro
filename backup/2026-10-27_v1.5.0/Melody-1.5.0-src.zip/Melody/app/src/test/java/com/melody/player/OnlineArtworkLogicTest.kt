package com.melody.player

import com.melody.player.data.artwork.AlbumMeta
import com.melody.player.data.artwork.OnlineArtworkClient
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** 在线封面匹配/解析逻辑的纯 JVM 测试，不联网。 */
class OnlineArtworkLogicTest {

    // ------------------------------------------------------------------ 归一化

    @Test
    fun `normalize strips brackets and punctuation`() {
        assertEquals("魔杰座", OnlineArtworkClient.normalize("魔杰座 (Deluxe Edition)"))
        assertEquals("稻香", OnlineArtworkClient.normalize("《稻香》"))
        assertEquals("album", OnlineArtworkClient.normalize("Album【Remastered 2011】"))
        assertEquals("jaychou", OnlineArtworkClient.normalize("Jay Chou"))
        assertEquals("", OnlineArtworkClient.normalize("   "))
    }

    @Test
    fun `normalize converts full width characters`() {
        assertEquals("123abc", OnlineArtworkClient.normalize("１２３ＡＢＣ"))
    }

    // ------------------------------------------------------------------ 打分

    @Test
    fun `exact album and artist scores full`() {
        assertEquals(
            100,
            OnlineArtworkClient.scoreMatch("魔杰座", "周杰伦", "魔杰座", "周杰伦"),
        )
    }

    @Test
    fun `same album different artist is penalised`() {
        // 80 - 10 = 70，仍高于阈值，但低于"歌手也对得上"的候选
        val wrongArtist = OnlineArtworkClient.scoreMatch("魔杰座", "周杰伦", "魔杰座", "某某翻唱")
        val rightArtist = OnlineArtworkClient.scoreMatch("魔杰座", "周杰伦", "魔杰座", "周杰伦")
        assertTrue(wrongArtist < rightArtist)
        assertEquals(70, wrongArtist)
    }

    @Test
    fun `album name containment still passes threshold`() {
        val score = OnlineArtworkClient.scoreMatch(
            "周杰伦地表最强世界巡回演唱会",
            "周杰伦",
            "地表最强世界巡回演唱会",
            "周杰伦",
        )
        assertTrue("包含关系应能通过 60 分阈值，实际 $score", score >= 60)
    }

    @Test
    fun `unrelated album and artist is rejected`() {
        val score = OnlineArtworkClient.scoreMatch("魔杰座", "周杰伦", "范特西", "陈奕迅")
        assertTrue("完全无关应被筛掉，实际 $score", score < 60)
    }

    @Test
    fun `missing local album falls back to artist only`() {
        assertEquals(70, OnlineArtworkClient.scoreMatch("", "周杰伦", "魔杰座", "周杰伦"))
        assertEquals(0, OnlineArtworkClient.scoreMatch("", "周杰伦", "魔杰座", "陈奕迅"))
        assertEquals(0, OnlineArtworkClient.scoreMatch("", "", "魔杰座", "周杰伦"))
    }

    // ------------------------------------------------------------------ iTunes 解析

    @Test
    fun `parse itunes results`() {
        val body = """
            {
              "resultCount": 2,
              "results": [
                {
                  "collectionName": "魔杰座",
                  "artistName": "周杰伦",
                  "artworkUrl100": "https://is1-ssl.mzstatic.com/image/thumb/a.jpg/100x100bb.jpg"
                },
                {
                  "collectionName": "跨时代",
                  "artistName": "周杰伦",
                  "artworkUrl100": "https://is1-ssl.mzstatic.com/image/thumb/b.jpg/100x100bb.jpg"
                },
                { "artistName": "没有封面的条目" }
              ]
            }
        """.trimIndent()

        val parsed = OnlineArtworkClient.parseItunes(body)
        assertEquals(2, parsed.size)
        assertEquals("魔杰座", parsed[0].first)
        assertEquals("周杰伦", parsed[0].second)
        assertTrue(parsed[0].third.contains("100x100bb"))
    }

    @Test
    fun `parse itunes tolerates broken json`() {
        assertTrue(OnlineArtworkClient.parseItunes("<html>403</html>").isEmpty())
        assertTrue(OnlineArtworkClient.parseItunes("{}").isEmpty())
    }

    // ------------------------------------------------------------------ 图片校验

    @Test
    fun `rejects tiny payloads and non images`() {
        // 太小（占位图 / 错误页）
        assertFalse(OnlineArtworkClient.looksLikeImage(ByteArray(1024)))
        // 体积够了但不是图片
        assertFalse(OnlineArtworkClient.looksLikeImage(ByteArray(8 * 1024)))
    }

    @Test
    fun `accepts jpeg and png magic`() {
        val jpeg = ByteArray(8 * 1024).apply {
            this[0] = 0xFF.toByte()
            this[1] = 0xD8.toByte()
            this[2] = 0xFF.toByte()
        }
        assertTrue(OnlineArtworkClient.looksLikeImage(jpeg))

        val png = ByteArray(8 * 1024).apply {
            this[0] = 0x89.toByte()
            this[1] = 0x50.toByte()
            this[2] = 0x4E.toByte()
            this[3] = 0x47.toByte()
        }
        assertTrue(OnlineArtworkClient.looksLikeImage(png))
    }

    // ------------------------------------------------------------------ 元信息

    @Test
    fun `album meta usability`() {
        assertTrue(AlbumMeta(1, "魔杰座", "周杰伦", "稻香").hasUsableText)
        assertTrue(AlbumMeta(1, "", "周杰伦", "稻香").hasUsableText)
        assertFalse(AlbumMeta(1, "", "", "稻香").hasUsableText)
    }
}
