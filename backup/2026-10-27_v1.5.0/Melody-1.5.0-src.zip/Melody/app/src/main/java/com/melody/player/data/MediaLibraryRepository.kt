package com.melody.player.data

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import com.melody.player.data.model.Album
import com.melody.player.data.model.Artist
import com.melody.player.data.model.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.Collator
import java.util.Locale

data class LibraryData(
    val tracks: List<Track> = emptyList(),
    val albums: List<Album> = emptyList(),
    val artists: List<Artist> = emptyList(),
)

/**
 * 通过 MediaStore 扫描设备中的本地音频（MP3 / FLAC / M4A / OGG / WAV ...），
 * 并派生出专辑、艺术家两类聚合数据。
 */
class MediaLibraryRepository(private val context: Context) {

    suspend fun load(sortOrder: Int): LibraryData = withContext(Dispatchers.IO) {
        val tracks = queryTracks()
        val collator = Collator.getInstance(Locale.SIMPLIFIED_CHINESE)

        val sorted = when (sortOrder) {
            SORT_RECENT -> tracks.sortedByDescending { it.dateAdded }
            SORT_ARTIST -> tracks.sortedWith(
                compareBy<Track, String>(collator) { it.artist }.thenBy(collator) { it.title }
            )
            else -> tracks.sortedWith(compareBy(collator) { it.title })
        }

        val albums = tracks
            .groupBy { it.albumId }
            .map { (albumId, list) ->
                Album(
                    id = albumId,
                    title = list.first().album,
                    artist = list.groupingBy { it.artist }
                        .eachCount()
                        .maxByOrNull { it.value }
                        ?.key
                        ?: list.first().artist,
                    year = list.maxOfOrNull { it.year } ?: 0,
                    tracks = list.sortedWith(
                        compareBy<Track> { track -> track.trackNumber }.thenBy(collator) { it.title }
                    ),
                )
            }
            .sortedWith(compareBy(collator) { it.title })

        val artists = tracks
            .groupBy { it.artistId }
            .map { (artistId, list) ->
                Artist(
                    id = artistId,
                    name = list.first().artist,
                    tracks = list.sortedWith(compareBy(collator) { it.title }),
                    albumCount = list.map { it.albumId }.distinct().size,
                )
            }
            .sortedWith(compareBy(collator) { it.name })

        LibraryData(sorted, albums, artists)
    }

    private fun queryTracks(): List<Track> {
        val resolver = context.contentResolver
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ARTIST_ID,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DATE_ADDED,
        )

        val result = ArrayList<Track>(256)
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"

        resolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection,
            selection,
            null,
            null,
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val artistIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST_ID)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val trackCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
            val yearCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)
            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val duration = cursor.getLong(durationCol)
                // 过滤铃声、提示音等过短音频
                if (duration < MIN_DURATION_MS) continue

                val rawTitle = cursor.getString(titleCol)
                val rawArtist = cursor.getString(artistCol)
                val rawAlbum = cursor.getString(albumCol)

                result += Track(
                    id = id,
                    title = rawTitle?.takeIf { it.isNotBlank() } ?: "未知曲目",
                    artist = rawArtist?.takeIf { it.isNotBlank() && it != "<unknown>" }
                        ?: "未知艺术家",
                    artistId = if (cursor.isNull(artistIdCol)) 0L else cursor.getLong(artistIdCol),
                    album = rawAlbum?.takeIf { it.isNotBlank() && it != "<unknown>" }
                        ?: "未知专辑",
                    albumId = if (cursor.isNull(albumIdCol)) 0L else cursor.getLong(albumIdCol),
                    durationMs = duration,
                    trackNumber = cursor.getInt(trackCol) % 1000,
                    year = cursor.getInt(yearCol),
                    path = if (cursor.isNull(dataCol)) null else cursor.getString(dataCol),
                    uriString = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        id,
                    ).toString(),
                    dateAdded = cursor.getLong(dateCol) * 1000L,
                )
            }
        }
        return result
    }

    companion object {
        const val SORT_TITLE = 0
        const val SORT_RECENT = 1
        const val SORT_ARTIST = 2

        private const val MIN_DURATION_MS = 15_000L
    }
}
