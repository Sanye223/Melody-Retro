package com.melody.player.data.artwork

import android.util.Log
import com.melody.player.data.lyrics.QqMusicClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URI
import java.net.URLEncoder
import java.util.Locale

/**
 * 一张专辑在本地能拿到的元信息，用于在线检索。
 * 全部来自 MediaStore，不额外读文件，避免影响扫描/播放性能。
 */
data class AlbumMeta(
    val albumId: Long,
    val album: String,
    val artist: String,
    val trackTitle: String,
) {
    val hasUsableText: Boolean
        get() = album.isNotBlank() || (trackTitle.isNotBlank() && artist.isNotBlank())
}

/** 在线检索到的封面候选。 */
data class CoverHit(
    val url: String,
    val albumName: String,
    val artistName: String,
    /** 展示用数据源名，例如 "QQ音乐"。 */
    val source: String,
    /** 匹配得分，越高越可信。 */
    val score: Int,
)

/**
 * 在线专辑封面检索。
 *
 * 优先级（命中即返回，失败才降级）：
 *
 * 1. **QQ音乐**：复用歌词模块的搜索接口拿到 `albummid`，再拼封面地址
 *    `https://y.gtimg.cn/music/photo_new/T002R500x500M000<albummid>.jpg`。
 *    华语/日韩命中率最高；不存在的专辑直接 404，很容易判别。
 * 2. **iTunes Search**：`search?term=&entity=album`，把 `artworkUrl100` 里的
 *    `100x100bb` 换成 `600x600bb` 拿大图。用于补 QQ 音乐没有的欧美曲目。
 *
 * 两者都只用到歌名 / 艺术家 / 专辑名这类公开元数据，不发送设备标识。
 * 任何一档都可能因为网络或接口变动失效，因此都包在 try/catch 里，抛错即降级。
 */
object OnlineArtworkClient {

    private const val TAG = "OnlineArtwork"

    private const val QQ_COVER = "https://y.gtimg.cn/music/photo_new/T002R500x500M000"
    private const val ITUNES_SEARCH = "https://itunes.apple.com/search"

    private const val CONNECT_TIMEOUT_MS = 4_000
    private const val READ_TIMEOUT_MS = 6_000

    /** 小于这个体积的响应基本都是占位图/错误页，直接丢弃。 */
    private const val MIN_IMAGE_BYTES = 6 * 1024

    /** 单张封面最大接受体积，防止误下大文件。 */
    private const val MAX_IMAGE_BYTES = 4 * 1024 * 1024

    private val jsonHeaders = mapOf(
        "Accept" to "application/json",
        "Accept-Language" to "zh-CN,zh;q=0.9,en;q=0.8",
    )

    /** 检索结果：把"确实没有"和"这次没连上"分开，二者的缓存策略不同。 */
    sealed interface LookupResult {
        data class Found(val cover: FetchedCover) : LookupResult
        data object NoMatch : LookupResult
        data class Failed(val reason: String) : LookupResult
    }

    private const val UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

    /**
     * 依次询问各数据源，返回最可信且已通过体积校验的封面字节。
     * 全部失败时返回 null（调用方据此走"无封面"降级），不会抛异常。
     */
    suspend fun fetchCover(meta: AlbumMeta): LookupResult {
        if (!meta.hasUsableText) return LookupResult.NoMatch

        val qq = searchQq(meta)
        val hits = if (qq.hits.isNotEmpty()) qq.hits else searchItunes(meta).hits
        if (hits.isEmpty()) {
            val failed = qq.failed
            if (failed) {
                Log.i(TAG, "search failed for ${meta.album}/${meta.artist}")
                return LookupResult.Failed("search failed")
            }
            Log.i(TAG, "no candidate for ${meta.album}/${meta.artist}")
            return LookupResult.NoMatch
        }

        // 同一数据源内按得分降序，逐个试下载，第一个能用的就用
        for (hit in hits.sortedByDescending { it.score }) {
            val bytes = download(hit.url)
            if (bytes != null) {
                Log.i(TAG, "cover ok: ${hit.source} score=${hit.score} ${hit.albumName}")
                return LookupResult.Found(FetchedCover(bytes, hit))
            }
        }
        Log.i(TAG, "all candidates unreadable for ${meta.album}/${meta.artist}")
        return LookupResult.Failed("download failed")
    }

    data class FetchedCover(val bytes: ByteArray, val hit: CoverHit)

    // ------------------------------------------------------------------ QQ 音乐

    /** 搜索产物：候选列表 + 本次是否发生过网络/解析错误。 */
    private data class SearchOutcome(val hits: List<CoverHit>, val failed: Boolean)

    private suspend fun searchQq(meta: AlbumMeta): SearchOutcome = runCatching {
        val keyword = buildString {
            append(meta.trackTitle.ifBlank { meta.album })
            if (meta.artist.isNotBlank()) {
                append(' ')
                append(meta.artist)
            }
        }.trim()
        if (keyword.isBlank()) return@runCatching emptyList()

        QqMusicClient.search(keyword, limit = 10).mapNotNull { song ->
            val albumMid = song.albumMid
            if (albumMid.isBlank()) return@mapNotNull null
            val albumName = song.album.orEmpty()
            val score = scoreMatch(
                wantAlbum = meta.album,
                wantArtist = meta.artist,
                gotAlbum = albumName,
                gotArtist = song.singers,
            )
            if (score < WEAK_THRESHOLD) return@mapNotNull null
            CoverHit(
                url = QQ_COVER + albumMid + ".jpg",
                albumName = albumName,
                artistName = song.singers,
                source = "QQ音乐",
                score = score,
            )
        }.distinctBy { it.url }
    }.fold(
        onSuccess = { SearchOutcome(it, failed = false) },
        onFailure = {
            Log.w(TAG, "qq search failed: ${it.javaClass.simpleName}: ${it.message}")
            SearchOutcome(emptyList(), failed = true)
        },
    )

    // ------------------------------------------------------------------ iTunes

    private suspend fun searchItunes(meta: AlbumMeta): SearchOutcome = runCatching {
        val term = buildString {
            append(meta.album.ifBlank { meta.trackTitle })
            if (meta.artist.isNotBlank()) {
                append(' ')
                append(meta.artist)
            }
        }.trim()
        if (term.isBlank()) return@runCatching emptyList()

        val url = buildString {
            append(ITUNES_SEARCH)
            append("?term=").append(URLEncoder.encode(term, "UTF-8"))
            append("&entity=album&limit=8&country=cn")
        }
        val body = httpGet(url, jsonHeaders)
        parseItunes(body).mapNotNull { (albumName, artistName, artworkUrl) ->
            val score = scoreMatch(meta.album, meta.artist, albumName, artistName)
            if (score < WEAK_THRESHOLD) return@mapNotNull null
            CoverHit(
                url = artworkUrl.replace("100x100bb", "600x600bb"),
                albumName = albumName,
                artistName = artistName,
                source = "iTunes",
                score = score,
            )
        }.distinctBy { it.url }
    }.fold(
        onSuccess = { SearchOutcome(it, failed = false) },
        onFailure = {
            Log.w(TAG, "itunes search failed: ${it.javaClass.simpleName}: ${it.message}")
            SearchOutcome(emptyList(), failed = true)
        },
    )

    /** 解析 iTunes 结果，返回 (专辑名, 歌手, 封面地址)。 */
    internal fun parseItunes(body: String): List<Triple<String, String, String>> {
        val root = runCatching { JSONObject(body) }.getOrNull() ?: return emptyList()
        val results = root.optJSONArray("results") ?: return emptyList()
        val out = ArrayList<Triple<String, String, String>>(results.length())
        for (i in 0 until results.length()) {
            val item = results.optJSONObject(i) ?: continue
            val album = item.optString("collectionName").takeIf { it.isNotBlank() } ?: continue
            val artist = item.optString("artistName").orEmpty()
            val artwork = item.optString("artworkUrl100").takeIf { it.isNotBlank() } ?: continue
            out += Triple(album, artist, artwork)
        }
        return out
    }

    // ------------------------------------------------------------------ 匹配打分

    /** 低于该分数视为"不是同一张专辑"，直接丢候选，宁缺毋滥。 */
    private const val WEAK_THRESHOLD = 60

    /**
     * 匹配打分（0-100），低于 [WEAK_THRESHOLD] 的候选直接丢弃：
     *
     * - 专辑名归一化后完全相同 +80；互相包含 +55；否则 0 —— 专辑名是主判据。
     * - 歌手归一化后相同 +20；互相包含 +14；完全无关 -10（挡掉同名不同歌手的翻唱）。
     * - 本地元数据没有专辑名时（单曲、标签不全），退化为"只要求艺术家一致"：
     *   完全相同 70、互相包含 62，否则 0。
     *
     * 因此"同名但歌手不同"的候选会掉到 70 以下被筛掉，宁缺毋滥。
     */
    internal fun scoreMatch(
        wantAlbum: String,
        wantArtist: String,
        gotAlbum: String,
        gotArtist: String,
    ): Int {
        val albumA = normalize(wantAlbum)
        val albumB = normalize(gotAlbum)
        val artistA = normalize(wantArtist)
        val artistB = normalize(gotArtist)

        if (albumA.isEmpty()) {
            return when {
                artistA.isEmpty() || artistB.isEmpty() -> 0
                artistA == artistB -> 70
                artistA.contains(artistB) || artistB.contains(artistA) -> 62
                else -> 0
            }
        }

        val albumScore = when {
            albumA == albumB -> 80
            albumB.isNotEmpty() && (albumA.contains(albumB) || albumB.contains(albumA)) -> 55
            else -> 0
        }
        val artistScore = when {
            artistA.isEmpty() || artistB.isEmpty() -> 0
            artistA == artistB -> 20
            artistA.contains(artistB) || artistB.contains(artistA) -> 14
            else -> -10
        }
        return (albumScore + artistScore).coerceIn(0, 100)
    }

    /**
     * 归一化：小写、全角转半角、去掉括号内补充信息（(Live)/(Remastered) 等）、
     * 去掉所有非字母数字与汉字。
     */
    internal fun normalize(value: String): String {
        if (value.isBlank()) return ""
        val sb = StringBuilder(value.length)
        var depth = 0
        for (ch in value) {
            when (ch) {
                '(', '（', '[', '【' -> depth++
                ')', '）', ']', '】' -> if (depth > 0) depth--
                else -> if (depth == 0) sb.append(ch)
            }
        }
        return buildString {
            for (ch in sb) {
                val mapped = when {
                    ch.code in 0xFF01..0xFF5E -> (ch.code - 0xFEE0).toChar()
                    ch == '\u3000' -> ' '
                    else -> ch
                }
                if (mapped.isLetterOrDigit()) append(mapped)
            }
        }.lowercase(Locale.ROOT)
    }

    // ------------------------------------------------------------------ HTTP

    private fun httpGet(url: String, headers: Map<String, String>): String {
        var connection: HttpURLConnection? = null
        try {
            connection = (URI.create(url).toURL().openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", UA)
                headers.forEach { (k, v) -> setRequestProperty(k, v) }
            }
            val code = connection.responseCode
            if (code !in 200..299) error("HTTP $code")
            return connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            runCatching { connection?.disconnect() }
        }
    }

    /**
     * 下载并做最基本的合法性校验：HTTP 200、content-type 是图片（有的 CDN 会缺省）、
     * 体积在 [MIN_IMAGE_BYTES]~[MAX_IMAGE_BYTES] 之间、且 JPEG/PNG 魔数匹配。
     *
     * 这三条能挡掉大部分"找不到就用默认灰图/1px 图/错误页"的情况，
     * 避免把占位图当封面缓存下来。
     */
    private suspend fun download(url: String): ByteArray? = withContext(Dispatchers.IO) {
        var connection: HttpURLConnection? = null
        try {
            connection = (URI.create(url).toURL().openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", UA)
                setRequestProperty("Accept", "image/jpeg,image/png,image/*;q=0.8")
            }
            val code = connection.responseCode
            if (code !in 200..299) {
                Log.i(TAG, "cover HTTP $code: $url")
                return@withContext null
            }
            val type = connection.contentType.orEmpty()
            if (type.isNotBlank() && !type.startsWith("image/")) {
                Log.i(TAG, "cover not an image ($type): $url")
                return@withContext null
            }
            val bytes = connection.inputStream.use { input ->
                val buffer = java.io.ByteArrayOutputStream(64 * 1024)
                val chunk = ByteArray(16 * 1024)
                var total = 0
                while (true) {
                    val read = input.read(chunk)
                    if (read <= 0) break
                    total += read
                    if (total > MAX_IMAGE_BYTES) return@use null
                    buffer.write(chunk, 0, read)
                }
                buffer.toByteArray()
            } ?: return@withContext null
            if (!looksLikeImage(bytes)) {
                Log.i(TAG, "cover rejected (${bytes.size}B): $url")
                return@withContext null
            }
            bytes
        } catch (throwable: Exception) {
            Log.w(TAG, "cover download failed: ${throwable.javaClass.simpleName}")
            null
        } finally {
            runCatching { connection?.disconnect() }
        }
    }

    /** JPEG(FFD8FF) / PNG(89504E47) / WebP(RIFF....WEBP) 魔数 + 最小体积。 */
    internal fun looksLikeImage(bytes: ByteArray): Boolean {
        if (bytes.size < MIN_IMAGE_BYTES) return false
        val jpeg = bytes.size > 3 &&
            bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte() && bytes[2] == 0xFF.toByte()
        if (jpeg) return true
        val png = bytes.size > 8 &&
            bytes[0] == 0x89.toByte() && bytes[1] == 0x50.toByte() &&
            bytes[2] == 0x4E.toByte() && bytes[3] == 0x47.toByte()
        if (png) return true
        val webp = bytes.size > 12 &&
            bytes[0] == 'R'.code.toByte() && bytes[1] == 'I'.code.toByte() &&
            bytes[2] == 'F'.code.toByte() && bytes[3] == 'F'.code.toByte() &&
            bytes[8] == 'W'.code.toByte() && bytes[9] == 'E'.code.toByte()
        return webp
    }
}
