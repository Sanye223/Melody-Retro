package com.melody.player.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Notes
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.Player
import com.melody.player.data.model.Lyrics
import com.melody.player.data.model.LyricsQuery
import com.melody.player.data.model.LyricsResult
import com.melody.player.data.model.LyricsSource
import com.melody.player.data.TrackInfo
import com.melody.player.data.TrackInfoStore
import com.melody.player.playback.NowPlaying
import com.melody.player.playback.PlayerUiState
import com.melody.player.ui.LocalOnlineLyrics
import com.melody.player.ui.LocalLyricFontScale
import com.melody.player.ui.LocalLyricSpacing
import com.melody.player.ui.LocalShowTrackInfo
import com.melody.player.ui.LocalPlayerActions
import com.melody.player.ui.LocalPlayerState
import com.melody.player.ui.LyricsViewModel
import com.melody.player.ui.NoInsets
import com.melody.player.ui.PlayerActions
import com.melody.player.ui.components.AlbumArt
import com.melody.player.util.formatDuration
import kotlinx.coroutines.delay

/** 点击歌词行后点亮保持的时长，之后恢复原状。 */
private const val FLASH_DURATION_MS = 420L


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlayingScreen(onBack: () -> Unit) {
    val state = LocalPlayerState.current
    val actions = LocalPlayerActions.current
    val current = state.current

    if (current == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
                text = "还没有正在播放的歌曲",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        return
    }

    val pagerState = rememberPagerState(pageCount = { 2 })

    Scaffold(
        containerColor = MaterialTheme.colorScheme.surface,
        contentWindowInsets = NoInsets,
        topBar = {
            CenterAlignedTopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = "收起")
                    }
                },
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "正在播放",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                            text = current.album,
                            style = MaterialTheme.typography.titleSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
        ) {
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.weight(1f),
            ) { page ->
                if (page == 0) {
                    ArtworkPage(current)
                } else {
                    LyricsPage(state, accent = MaterialTheme.colorScheme.primary)
                }
            }
            PageDots(count = 2, current = pagerState.currentPage)
            SeekBar(state = state, actions = actions)
            TransportControls(state = state, actions = actions)
        }
    }
}

@Composable
private fun ArtworkPage(current: NowPlaying) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        AlbumArt(
            albumId = current.albumId,
            modifier = Modifier
                .widthIn(max = 420.dp)
                .fillMaxWidth()
                .aspectRatio(1f),
            shape = RoundedCornerShape(28.dp),
            iconFraction = 0.26f,
        )
        Spacer(Modifier.height(34.dp))
        Text(
            text = current.title,
            style = MaterialTheme.typography.headlineSmall,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = current.artist,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        TrackInfoRow(current)
    }
}

/**
 * 额外歌曲信息：格式 · 位深 · 码率 · 采样率，例如 `FLAC · 24 bit · 1411 kbps · 48 kHz`。
 * 设置里关掉就整行不渲染；解析不出来时也不占位（不留空行）。
 *
 * 位深只对无损格式（FLAC / WAV / AIFF）有意义，有损格式自动省略；
 * 容器头没给码率时按「体积 ÷ 时长」估算，前面加 `≈` 表示是估算值。
 */
@Composable
private fun TrackInfoRow(current: NowPlaying) {
    if (!LocalShowTrackInfo.current) return
    val context = LocalContext.current
    var info by remember(current.id) { mutableStateOf<TrackInfo?>(null) }

    LaunchedEffect(current.id) {
        info = TrackInfoStore.info(context, current.id, current.path, current.durationMs)
    }

    val summary = info?.summary().orEmpty()
    if (summary.isBlank()) return
    Spacer(Modifier.height(10.dp))
    Surface(
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
    ) {
        Text(
            text = summary,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
        )
    }
}

// ------------------------------------------------------------------ 歌词页

@Composable
private fun LyricsPage(state: PlayerUiState, accent: Color) {
    val current = state.current ?: return
    val onlineEnabled = LocalOnlineLyrics.current
    val viewModel: LyricsViewModel = viewModel()
    val ui by viewModel.state.collectAsStateWithLifecycle()

    LaunchedEffect(current.id, current.title, onlineEnabled) {
        viewModel.load(
            query = LyricsQuery(
                id = current.id,
                path = current.path,
                title = current.title,
                artist = current.artist,
                album = current.album,
                durationMs = current.durationMs,
            ),
            onlineEnabled = onlineEnabled,
        )
    }

    val result = ui.result
    when {
        ui.loading -> LyricsLoading(onlineEnabled)

        result.isEmpty -> NoLyrics(
            onlineEnabled = onlineEnabled,
            message = result.message,
            onRetry = viewModel::retry,
        )

        else -> LyricsContent(
            result = result,
            positionMs = state.positionMs,
            accent = accent,
        )
    }
}

@Composable
private fun LyricsContent(result: LyricsResult, positionMs: Long, accent: Color) {
    val lyrics: Lyrics = result.lyrics ?: return
    val fontScale = LocalLyricFontScale.current
    val spacing = LocalLyricSpacing.current.dp
    val lyricStyle = MaterialTheme.typography.bodyLarge.copy(
        fontSize = MaterialTheme.typography.bodyLarge.fontSize * fontScale,
        lineHeight = MaterialTheme.typography.bodyLarge.lineHeight * fontScale,
    )
    val listState = rememberLazyListState()
    val actions = LocalPlayerActions.current
    val activeIndex = if (lyrics.synced) lyrics.indexAt(positionMs) else -1

    // 点击瞬间短暂点亮的行；tick 用于每次点击都重新计时
    var flashIndex by remember { mutableIntStateOf(-1) }
    var flashTick by remember { mutableIntStateOf(0) }

    LaunchedEffect(flashTick) {
        if (flashTick > 0) {
            delay(FLASH_DURATION_MS)
            flashIndex = -1
        }
    }

    LaunchedEffect(activeIndex, lyrics) {
        if (activeIndex >= 0) {
            listState.animateScrollToItem(activeIndex)
        }
    }

    Column(Modifier.fillMaxSize()) {
        LyricsSourceBadge(result)
        BoxWithConstraints(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
        ) {
            val centerPadding = ((maxHeight - 72.dp) / 2).coerceAtLeast(0.dp)
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 24.dp, vertical = centerPadding),
            ) {
                itemsIndexed(lyrics.lines) { index, line ->
                    val active = index == activeIndex
                    val flashing = index == flashIndex
                    // 当前行只用「主题色 + 半粗」区分，不再有任何边框/底色；
                    // 其它行降低透明度形成对比。
                    // 高亮色跟随播放控件主色（Retro 版是封面取色的 accent）
                    val color by animateColorAsState(
                        targetValue = when {
                            flashing -> MaterialTheme.colorScheme.onSurface
                            active -> accent
                            else -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f)
                        },
                        animationSpec = tween(durationMillis = if (flashing) 80 else 260),
                        label = "lyricColor",
                    )
                    // 点击时短暂亮起的一层柔光，随后淡出恢复原状
                    val flashAlpha by animateFloatAsState(
                        targetValue = if (flashing) 1f else 0f,
                        animationSpec = tween(durationMillis = if (flashing) 70 else 380),
                        label = "lyricFlash",
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(accent.copy(alpha = 0.16f * flashAlpha))
                            // 关掉默认水波纹（整行的涟漪看起来就像一块大色块），
                            // 点击反馈统一由上面的短暂点亮承担
                            .clickable(
                                enabled = lyrics.synced,
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null,
                            ) {
                                flashIndex = index
                                flashTick++
                                if (line.timeMs >= 0) actions.seekTo(line.timeMs)
                            }
                            .padding(horizontal = 10.dp, vertical = spacing),
                        contentAlignment = Alignment.CenterStart,
                    ) {
                        Text(
                            text = line.text,
                            color = color,
                            style = lyricStyle,
                            fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                            textAlign = TextAlign.Start,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LyricsSourceBadge(result: LyricsResult) {
    val label = when (result.source) {
        LyricsSource.ONLINE -> buildString {
            append(result.provider ?: "在线歌词")
            result.matched?.takeIf { it.isNotBlank() }?.let { append(" · ").append(it) }
        }
        LyricsSource.LOCAL_FILE -> "本地歌词文件"
        LyricsSource.NONE -> return
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
        horizontalArrangement = Arrangement.Center,
    ) {
        Surface(
            shape = RoundedCornerShape(50),
            color = if (result.source == LyricsSource.ONLINE) {
                MaterialTheme.colorScheme.secondaryContainer
            } else {
                MaterialTheme.colorScheme.surfaceVariant
            },
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = if (result.source == LyricsSource.ONLINE) {
                    MaterialTheme.colorScheme.onSecondaryContainer
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                },
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
            )
        }
    }
}

@Composable
private fun LyricsLoading(onlineEnabled: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        CircularProgressIndicator()
        Spacer(Modifier.height(18.dp))
        Text(
            text = if (onlineEnabled) "正在获取在线歌词…" else "正在读取歌词…",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun NoLyrics(onlineEnabled: Boolean, message: String?, onRetry: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            imageVector = Icons.Rounded.Notes,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(48.dp),
        )
        Spacer(Modifier.height(16.dp))
        Text(text = "暂无歌词", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Text(
            text = buildString {
                if (!message.isNullOrBlank()) {
                    append(message)
                    append("\n")
                }
                if (onlineEnabled) {
                    append("也可把同名 .lrc 文件放到歌曲所在目录。")
                } else {
                    append("在线歌词已在设置中关闭，\n可开启后自动从 LRCLIB 获取。")
                }
            },
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        if (onlineEnabled) {
            Spacer(Modifier.height(12.dp))
            TextButton(onClick = onRetry) {
                Icon(
                    imageVector = Icons.Rounded.Refresh,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text("重新搜索在线歌词")
            }
        }
    }
}

// ------------------------------------------------------------------ 通用控件

@Composable
private fun PageDots(count: Int, current: Int) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.Center,
    ) {
        repeat(count) { index ->
            val active = index == current
            val color by animateColorAsState(
                targetValue = if (active) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f),
                label = "dotColor",
            )
            Box(
                modifier = Modifier
                    .padding(horizontal = 4.dp)
                    .size(width = if (active) 18.dp else 8.dp, height = 8.dp)
                    .clip(CircleShape)
                    .background(color),
            )
        }
    }
}

@Composable
private fun SeekBar(state: PlayerUiState, actions: PlayerActions) {
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }

    val duration = state.durationMs.coerceAtLeast(1L)
    val sliderValue = if (dragging) {
        dragValue
    } else {
        (state.positionMs.toFloat() / duration).coerceIn(0f, 1f)
    }
    val displayedPosition = if (dragging) (dragValue * duration).toLong() else state.positionMs

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp),
    ) {
        Slider(
            value = sliderValue,
            onValueChange = { value ->
                dragging = true
                dragValue = value
            },
            onValueChangeFinished = {
                dragging = false
                actions.seekTo((dragValue * duration).toLong())
            },
            valueRange = 0f..1f,
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text = formatDuration(displayedPosition),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                text = formatDuration(state.durationMs),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun TransportControls(state: PlayerUiState, actions: PlayerActions) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = actions.toggleShuffle) {
            Icon(
                imageVector = Icons.Rounded.Shuffle,
                contentDescription = "随机播放",
                tint = if (state.shuffle) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        FilledTonalIconButton(
            onClick = actions.previous,
            modifier = Modifier.size(56.dp),
        ) {
            Icon(
                imageVector = Icons.Rounded.SkipPrevious,
                contentDescription = "上一曲",
                modifier = Modifier.size(30.dp),
            )
        }
        FilledIconButton(
            onClick = actions.togglePlayPause,
            modifier = Modifier.size(78.dp),
        ) {
            Icon(
                imageVector = if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                contentDescription = if (state.isPlaying) "暂停" else "播放",
                modifier = Modifier.size(38.dp),
            )
        }
        FilledTonalIconButton(
            onClick = actions.next,
            modifier = Modifier.size(56.dp),
            enabled = state.hasNext,
        ) {
            Icon(
                imageVector = Icons.Rounded.SkipNext,
                contentDescription = "下一曲",
                modifier = Modifier.size(30.dp),
            )
        }
        IconButton(onClick = actions.cycleRepeatMode) {
            Icon(
                imageVector = if (state.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne
                else Icons.Rounded.Repeat,
                contentDescription = "循环模式",
                tint = if (state.repeatMode != Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
